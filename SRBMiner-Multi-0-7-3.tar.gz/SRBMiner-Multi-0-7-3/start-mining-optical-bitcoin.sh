#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-cpu --algorithm heavyhash --pool obtc.suprnova.cc:4074 --wallet bc1qzd7tdx4xchh7kncrq05xehws37t3d2z28nhl2d
